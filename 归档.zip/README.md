# 资源共享站
一个用PHP写的简易资源共享网站。

具备以下功能：
* 查找搜索资源
* 添加资源
* 删除资源
* 直接修改资源

(使用[Material Design Lite](https://github.com/google/material-design-lite)构建)
